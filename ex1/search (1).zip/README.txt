12345678
87654321
*****
Question 8 comments:
