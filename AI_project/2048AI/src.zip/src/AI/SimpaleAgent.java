package AI;

import java.util.ArrayList;
import java.util.List;

public class SimpaleAgent implements Agent{

	@Override
	public String[] getActions(int[] board, int[] score) {
		List<String> actions = new ArrayList<String>();
		actions.add("left");
		actions.add("up");
		actions.add("right");
		actions.add("down");

		String[] a = new String[actions.size()];
		// TODO Auto-generated method stub
		return actions.toArray(a);
	}

}
