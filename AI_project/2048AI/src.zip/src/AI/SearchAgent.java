package AI;

public class SearchAgent implements Agent{
	private int boardSize; 
	private Evaluation e;
	
	public SearchAgent(int boardSize, Evaluation e) {
		this.boardSize = boardSize;
		this.e = e;
	}
	
	@Override
	public String[] getActions(int[] board, int[] score) {
		// TODO Auto-generated method stub
		return null;
	}

}
