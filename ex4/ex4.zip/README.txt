304844517
303032510
*****

In this project we implemented valueIteration and Qlearning.
We learned how changing the values of alpha, discount and noise
affect the optimal policy. It was fun!

Question 3:
Explanation for our values:
a. we chose to give small value for discount so the agent will prefer the right
   exit, because the reward is closer.
b. we gave a small but yet important value for noise, so the agent will prefer
   to avoid the cliff.
c. We chose high discount value, so the agent will choose the distance exit.
d. We chose high discount value and higher leaving reward. This causes the agent
   avoiding the cliff.
e. We gave very high leaving reward so the agent will prefer to stay away from the
   terminal state.

Question 6:
Explanation why it is not possible:
In order to have a chance of succeeding the amount of episode should be
larger than 50 episodes, because there are a lot of terminal states.