12345678
87654321
*****
Question 5 comments:
