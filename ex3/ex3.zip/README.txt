304844517
303032510
*****

During this exercise we have learned about planning
problems and planning heuristics.
We Implemented the sum and max heuristics,
which was an interesting assignment.
It was fun!