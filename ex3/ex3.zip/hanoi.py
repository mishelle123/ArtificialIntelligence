import itertools

def createDomainFile(domainFileName, n):
  numbers = list(range(n)) # [0,...,n-1]
  pegs = ['a','b', 'c']
  domainFile = open(domainFileName, 'w') #use domainFile.write(str) to write to domainFile

  "*** YOUR CODE HERE ***"
  domainFile.write('Propositions:\n')
  propositions = list()
  space = " "
  #adds the At propositions
  for i in numbers:
    for peg in pegs:
      domainFile.write(str(i)+"At"+peg + space)
  #adds the clear propositions
  for i in numbers:
    domainFile.write("cl"+ str(i) + space)

  for i in numbers:
    for j in range(i+1,n):
      domainFile.write(str(i) + "On" + str(j) + space)
    domainFile.write(str(i) + "On" + "Floor" + space)


  for peg in pegs:
    domainFile.write(peg + "Empty" + space)

  domainFile.write("\n")

  domainFile.write('Actions:\n')
  #move
  for peg1, peg2 in itertools.product(pegs, pegs) :
    if peg1==peg2:
      continue
    for i in numbers:
      for j in range(i+1, n):
        for k in range(i+1, n):
          if k == j:
            continue
          domainFile.write("Name: ")
          #funciom name
          domainFile.write(str(i)+"On"+str(k)+peg1+peg2+str(j)+"\n")
          domainFile.write("pre: ")
          domainFile.write(str(i)+"On"+str(k)+space)
          domainFile.write("cl"+str(i)+space+"cl"+str(j)+space)
          domainFile.write(str(i)+"At"+peg1+space+str(k)+"At"+peg1+space+str(j)+"At"+peg2+"\n")

          domainFile.write("add: ")
          domainFile.write(str(i)+"On"+str(j)+space)
          domainFile.write("cl"+str(k)+space)
          domainFile.write(str(i)+"At"+peg2+"\n")

          domainFile.write("delete: ")
          domainFile.write(str(i)+"On"+str(k)+space)
          domainFile.write("cl"+str(j)+space)
          domainFile.write(str(i)+"At"+peg1+"\n")

    for i in numbers:
      for j in range(i+1, n):
        domainFile.write("Name: ")
        #funciom name
        domainFile.write(str(i)+"On"+str(j)+peg1+peg2+"Floor"+"\n")
        domainFile.write("pre: ")
        domainFile.write(str(i)+"On"+str(j)+space)
        domainFile.write("cl"+str(i)+space+peg2+"Empty"+space)
        domainFile.write(str(i)+"At"+peg1+space+str(j)+"At"+peg1+"\n")

        domainFile.write("add: ")
        domainFile.write(str(i)+"On"+"Floor"+space)
        domainFile.write("cl"+str(j)+space)
        domainFile.write(str(i)+"At"+peg2+"\n")

        domainFile.write("delete: ")
        domainFile.write(str(i)+"On"+str(j)+space)
        domainFile.write(peg2+"Empty"+space)
        domainFile.write(str(i)+"At"+peg1+"\n")

    for i in numbers:
      for j in range(i+1, n):
        domainFile.write("Name: ")
        #funciom name
        domainFile.write(str(i)+"On"+"Floor"+peg1+peg2+str(j)+"\n")
        domainFile.write("pre: ")
        domainFile.write(str(i)+"On"+"Floor"+space)
        domainFile.write("cl"+str(i)+space+"cl"+str(j)+space)
        domainFile.write(str(i)+"At"+peg1+space+str(j)+"At"+peg2+"\n")

        domainFile.write("add: ")
        domainFile.write(str(i)+"On"+str(j)+space)
        domainFile.write(peg1+"Empty"+space)
        domainFile.write(str(i)+"At"+peg2+"\n")

        domainFile.write("delete: ")
        domainFile.write(str(i)+"On"+"Floor"+space)
        domainFile.write("cl"+str(j)+space)
        domainFile.write(str(i)+"At"+peg1+"\n")

    for i in numbers:
      domainFile.write("Name: ")
      #funciom name
      domainFile.write(str(i)+"On"+"Floor"+peg1+peg2+"Floor"+"\n")
      domainFile.write("pre: ")
      domainFile.write(str(i)+"On"+"Floor"+space)
      domainFile.write("cl"+str(i)+space+peg2+"Empty"+space)
      domainFile.write(str(i)+"At"+peg1+"\n")

      domainFile.write("add: ")
      domainFile.write(peg1+"Empty"+space)
      domainFile.write(str(i)+"At"+peg2+"\n")

      domainFile.write("delete: ")
      domainFile.write(peg2+"Empty"+space)
      domainFile.write(str(i)+"At"+peg1+"\n")


  domainFile.close()
        
  
def createProblemFile(problemFileName, n):
  numbers = list(range(n)) # [0,...,n-1]
  pegs = ['a','b', 'c']
  problemFile = open(problemFileName, 'w') #use problemFile.write(str) to write to problemFile
  "*** YOUR CODE HERE ***"
  space = " "
  problemFile.write("Initial state: ")
  #adds the initial propositions
  for i in numbers:
    problemFile.write(str(i)+"At"+'a' + space)
    if i == n-1:
      problemFile.write(str(i)+"On"+ "Floor" + space)
    else:
      problemFile.write(str(i)+"On"+ str(i+1) + space)

  problemFile.write("cl"+str(0)+ space)
  problemFile.write("b"+"Empty"+ space)
  problemFile.write("c"+"Empty"+ "\n")

  problemFile.write("Goal state: ")
  for i in numbers:
    problemFile.write(str(i)+"At"+'c' + space)
    if i == n-1:
      problemFile.write(str(i)+"On"+ "Floor" + space)
    else:
      problemFile.write(str(i)+"On"+ str(i+1) + space)

  problemFile.write("cl"+str(0)+ space)
  problemFile.write("b"+"Empty"+ space)
  problemFile.write("a"+"Empty"+ "\n")

  problemFile.close()

import sys
if __name__ == '__main__':
  if len(sys.argv) != 2:
    print('Usage: hanoi.py n')
    sys.exit(2)
  
  n = int(float(sys.argv[1])) #number of disks
  domainFileName = 'hanoi' + str(n) + 'Domain.txt'
  problemFileName = 'hanoi' + str(n) + 'Problem.txt'
  
  createDomainFile(domainFileName, n)
  createProblemFile(problemFileName, n)